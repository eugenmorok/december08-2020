public class jkArrayTo {


    public static String stringOne(String inputArr[]) {

        String outputString = "";

        //System.out.println(inputArr[0]);

        for (int i = 0; i < inputArr.length; i++) {

            outputString += inputArr[i];

        }

        //System.out.println(outputString);

        return outputString;
    }

}